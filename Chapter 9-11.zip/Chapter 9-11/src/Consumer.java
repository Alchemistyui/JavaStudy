import java.io.IOException;
import java.io.PipedReader;

public class Consumer extends Thread {

	String consumerName;

	PipedReader in;
	
	public Consumer(String consumerName, PipedReader i) {
		this.consumerName = consumerName;
		in = i;
	}

	@Override
	public void run() {
		
		int foodNum = 0;
		try {
			foodNum = Integer.valueOf(in.read());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
		System.out.println(foodNum);
		
		while (true) {
			
		
			if (foodNum == 0) {
				System.out.println("box is empty,size = " + foodNum);
				break;
				
			}
			foodNum--;
			System.out.println("consume success foodNum = " + foodNum);


		}
	}

}
